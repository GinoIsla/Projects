/****************************************************************************
*  Filename: LCD.C
*****************************************************************************
*	Author:	 	Rodger Richey
*	Company:	Microchip Technology Incorporated
*	Revision:	A0
*	Date:		6-14-96
*	Compiled using MPLAB-C Version 00.00.14
*****************************************************************************
*	This file contains routines to output time, day of week, AM/PM, and
*	temperature.  It also contains routines to blink the different groupings
*	of numbers, i.e. hours,seconds,day of the week.  Finally, the last 
*	routine displays the state of the hourly beep.
****************************************************************************/

// Bit defines for the Mode variable, tells the UpdateLCD routine which
// groups of numbers to display
#define HOURS 0
#define MINUTES 1
#define DAYOFWEEK 2
#define PROG 5				// PROG icon
#define COLON 6				// colon, :, for the hours/seconds time display
#define DEGREES 7			// degrees symbol for temperature

/****************************************************************************
*	UpdateLCD
*	Function:	This function updates the LCD display based on the Mode
*				variable.
****************************************************************************/
void UpdateLCD(void)
{
// Array of 7-segment numbers
                                              //   gfedcba
        const unsigned char SevenSegTable[16]={ 0b00111111,	// Zero
                                                0b00000110, // One
                                                0b01011011, // Two
                                                0b01001111, // Three
                                                0b01100110, // Four
                                                0b01101101, // Five
                                                0b01111101, // Six
                                                0b00000111, // Seven
                                                0b01111111, // Eight
                                                0b01101111, // Nine
												0b01110111,	// Ten
												0b01111100,	// Eleven
												0b01011000,	// Twelve
												0b01011110,	// Thirteen
												0b01111001,	// Fourteen
												0b01110001};// Fifeteen

		// Temporary variables in common RAM locations
        bits segment @ 0x76;
        unsigned char index @ 0x77;

		// Change to Bank 2, and clear all LCD data RAM
        STATUS.RP1 = 1;
        LCDD00 = 0;
        LCDD01 = 0;
        LCDD04 = 0;
        LCDD05 = 0;
        LCDD08 = 0;
        LCDD09 = 0;
        LCDD12 = 0;
        LCDD13 = 0;
        
		// Update day of the week if enabled
        if(Mode.DAYOFWEEK)
        {
            // Update Day of the Week
            if(DayOfWeek == 0)				// Sunday
                LCDD00.0 = 1;
            else if(DayOfWeek == 1)			// Monday
                LCDD00.1 = 1;
            else if(DayOfWeek == 2)			// Tuesday
                LCDD00.2 = 1;
            else if(DayOfWeek == 3)			// Wednesday
                LCDD00.3 = 1;
            else if(DayOfWeek == 4)			// Thursday
                LCDD01.0 = 1;
            else if(DayOfWeek == 5)			// Friday
                LCDD00.4 = 1;
            else if(DayOfWeek == 6)			// Saturday
                LCDD00.5 = 1;
        }

        // Update Time if enabled
        if(Mode.HOURS)
        {
	        // Update AM/PM icons
    	    if(LStatus.AMPM)
        	        LCDD09.0 = 1;
	        else
    	            LCDD12.3 = 1;

            // Digit 1
            if(Hours&0x10)
                LCDD12.0 = 1;

            // Digit 2
            index = Hours & 0x0f;
            segment = SevenSegTable[index];
            if(segment.0)                           // D2.a
                LCDD13.3 = 1;
            if(segment.1)                           // D2.b
                LCDD12.1 = 1;
            if(segment.2)                           // D2.c
                LCDD05.3 = 1;
            if(segment.3)                           // D2.d
                LCDD01.3 = 1;
            if(segment.4)                           // D2.e
                LCDD04.0 = 1;
            if(segment.5)                           // D2.f
                LCDD08.0 = 1;
            if(segment.6)                           // D2.g
                LCDD09.3 = 1;
        }

		// Update Minutes if enabled
        if(Mode.MINUTES)
        {
            // Digit 3
            index = Minutes & 0xf0;
            index >>= 4;
            segment = SevenSegTable[index];
            if(segment.0)                           // D3.a
                LCDD13.2 = 1;
            if(segment.1)                           // D3.b
                LCDD08.2 = 1;
            if(segment.2)                           // D3.c
                LCDD04.2 = 1;
            if(segment.3)                           // D3.d
                LCDD01.2 = 1;
            if(segment.4)                           // D3.e
                LCDD04.1 = 1;
            if(segment.5)                           // D3.f
                LCDD09.2 = 1;
            if(segment.6)                           // D3.g
                LCDD05.2 = 1;

            // Digit 4
            index = Minutes & 0x0f;
            segment = SevenSegTable[index];
            if(segment.0)                           // D4.a
                LCDD13.1 = 1;
            if(segment.1)                           // D4.b
                LCDD08.3 = 1;
            if(segment.2)                           // D4.c
                LCDD04.3 = 1;
            if(segment.3)                           // D4.d
                LCDD01.1 = 1;
            if(segment.4)                           // D4.e
                LCDD05.1 = 1;
            if(segment.5)                           // D4.f
                LCDD12.2 = 1;
            if(segment.6)                           // D4.g
                LCDD09.1 = 1;
        }

		// Update Temperature
        // Digit 5
        index = TempC&0xf0;
        index >>= 4;
        segment = SevenSegTable[index];
        if(segment.0)                           // D5.a
                LCDD12.7 = 1;
        if(segment.1)                           // D5.b
                LCDD12.4 = 1;
        if(segment.2)                           // D5.c
                LCDD04.4 = 1;
        if(segment.3)                           // D5.d
                LCDD00.7 = 1;
        if(segment.4)                           // D5.e
                LCDD04.7 = 1;
        if(segment.5)                           // D5.f
                LCDD13.0 = 1;
        if(segment.6)                           // D5.g
                LCDD08.7 = 1;

        // Digit 6
        index = TempC&0x0f;
        segment = SevenSegTable[index];
        if(segment.0)                           // D6.a
                LCDD12.6 = 1;
        if(segment.1)                           // D6.b
                LCDD08.5 = 1;
        if(segment.2)                           // D6.c
                LCDD04.5 = 1;
        if(segment.3)                           // D6.d
                LCDD00.6 = 1;
        if(segment.4)                           // D6.e
                LCDD04.6 = 1;
        if(segment.5)                           // D6.f
                LCDD08.4 = 1;
        if(segment.6)                           // D6.g
                LCDD08.6 = 1;

        // Turn on : if enabled
        if(Mode.COLON)
                LCDD08.1 = 1;

        // Turn on degrees symbol if enabled
        if(Mode.DEGREES)
                LCDD12.5 = 1;

        // Turn on PROG symbol if enabled
        if(Mode.PROG)
                LCDD05.0 = 1;

        // Make copies of the LCD data registers
        LCDD02 = LCDD00;
        LCDD03 = LCDD01;
        LCDD06 = LCDD04;
        LCDD07 = LCDD05;
        LCDD10 = LCDD08;
        LCDD11 = LCDD09;
        LCDD14 = LCDD12;
        LCDD15 = LCDD13;
        
        STATUS.RP1 = 0;		// Return to Bank 0
        return;
}

/****************************************************************************
*	BlinkLCD
*	Function:	This function is used in program mode to blink hours, minutes
*				or day of the week depending on the current status.
****************************************************************************/
void BlinkLCD(bits which)
{
    if(Flags.UPDATE)				// If UPDATE flag is set, blank the
    {								// corresponding group
        Flags.UPDATE = 0;			// Clear UPDATE flag
        if(which==0x01)				// Blank Hours
        {
            Mode = 0b11100110;
            UpdateLCD();
        }
        else if(which == 0x02)		// Blank Minutes
        {
            Mode = 0b11100101;
            UpdateLCD();
        }
        else if(which == 0x04)		// Blank day of the week
        {
            Mode = 0b11100011;
            UpdateLCD();
        }
    }
    else							// Turn on all groups if UPDATE flag is
    {								// cleared
        Flags.UPDATE = 1;			// Set the UPDATE flag
        Mode = 0b11100111;			// Set bits in Mode to turn all on
        UpdateLCD();
    }
    return;
}

/****************************************************************************
*	DisplaySoundState
*	Function:	When the SOUND button is pressed the state of the hourly beep
*				is toggle between on and off.  This routine displays to the
*				user the state, Snd OF or Snd On.
****************************************************************************/
void DisplaySoundState(void)
{
    unsigned char frames;			// Frame count variable
    	
    frames = FRAME_COUNT;			// Initialize the frame counter

    while(!Flags.FRAME);				// Wait for next frame to occur
    Flags.FRAME = 0;				// Clear FRAME flag

    STATUS.RP1 = 1;					// Change to Bank 2
    LCDD00 = 0b10000000;			// Write the data that is common to both
    LCDD01 = 0b00001010;			// Snd On and Snd OF
    LCDD05 = 0b00001110;
    LCDD09 = 0b00001010;
    LCDD13 = 0b00001001;
    STATUS.RP1 = 0;					// Change to Bank 0

    if(Flags.SOUND_STATE)			// Sound on
    {
        STATUS.RP1 = 1;				// Change to Bank 2
        LCDD04 = 0b11111110;		// Write data that is specific to Snd On
        LCDD08 = 0b01001001;
        LCDD12 = 0b10010000;
    }
    else							// Sound off
    {
        STATUS.RP1 = 1;				// Change to Bank 2
        LCDD04 = 0b11011110;		// Write data that is specific to Snd OF
        LCDD08 = 0b01011001;
        LCDD12 = 0b11010000;
    }
    STATUS.RP1 = 0;					// Change to Bank 0

    while(frames)					// Delay a specific number of frames so
    {								// the user can see the message
        if(Flags.FRAME)				// Decrement frames until 0
        {
            Flags.FRAME = 0;
            frames--;
        }
    }
    return;
}

