/****************************************************************************
*  Filename: CLK.C
*****************************************************************************
*	Author:	 	Rodger Richey
*	Company:	Microchip Technology Incorporated
*	Revision:	A3
*	Date:		12-17-96
*	Compiled using MPLAB-C Version 1.20
*****************************************************************************
* 	Include files:
* 		16C924.h	Rev 1.00
* 		MUSIC.C		Rev A2
*		LCD.C		Rev A1
*		TIME.C		Rev A1
*****************************************************************************
*	Peripheral Modules Used:
*		Timer0	:	Used by the music generation program for timing notes
*					and durations
*		Timer1	:	Used as a real time clock using an external 32.768KHz
*					crystal and (2) 33pF capacitors
*		Timer2	:	Used in conjunction with the PWM
*		CCP		:	Used in PWM mode, for driving the piezo alarm
*		PORTB	:	Used to decode key presses
*		A/D		:	Used to measure temperature via a thermistor on RA0
*		LCD		:	Used to display time, temperature, day of week
*****************************************************************************
*	External Clock Frequency		: 4MHz
*	Timer1 OSC Frequency			: 32.768KHz
*	Configuration Bit Settings		: XT Oscillator
*									: Watchdog Timer OFF
*									: Code Protect OFF
*									: Power-Up Timer ON
*	Program Memory Usage			: 1095 words
*	Data Memory Usage				: 19 bytes
*****************************************************************************
*	Revision History
*	A1 - First Release
*	A2 - Added code to clear CCPR1L after PWM has finished
*	   - Set No sleep flag in StartMusic
*	A3 - Changed __INT interrupt service routine.  Added INTCON.T0IE to check
*	     for Timer0 interrupt
*****************************************************************************
*	Note: Make sure that the temporary variables in the 16c924.h file have
*	      been changed to locations 0x7a to 0x7f
****************************************************************************/
#include <16c924.h>
#include <delay14.h>

// PORTA pin defines
#define THERM_GND 2

// PORTB key defines
#define EXTRA 4
#define SOUND 5
#define UP 6
#define SET 7

// Variable declarations
bits Flags;						// Contains flag bits for various events
bits Temp;						// Temporary storage
bits Count;						// Number of Timer2 Interrupts to count
bits Ticks;						// Counts seconds will in program mode
bits Mode @ 0x78;				// Contains flag bits to turn on LCD pixels
unsigned char FrameCnt;			// Count LCD frames

// Bit defines for Flags
#define UPDATE 0
#define FRAME 1
#define PROGRAM 3
#define SOUND_STATE 4
#define SLEEP_STATE 5

// Time variables
unsigned char Seconds @ 0x70;	// Holds number of seconds
unsigned char Minutes @ 0x71;	// Holds number of minutes
unsigned char Hours @ 0x72;		// Holds number of hours
bits LStatus @ 0x73;            // bit 7 -> 0=AM, 1=PM
	                            // bits 0-3 -> 0000=SUN
bits DayOfWeek @0x74;			//             0001=MON
								//             0010=TUE
								//             0011=WED
								//             0100=THU
								//             0101=FRI
								//             0110=SAT

// Bit defines for LStatus
#define AMPM 7

// Temperature Variable
unsigned char TempC @ 0x75;

#define FRAME_COUNT 12			// Number of frames in blink in prgm mode
#define BEEP_COUNT 4			// PWM duty cycle value for "beep"

// Thermistor calibration table, 0C to 99C
const unsigned int ThermTable[] =
{
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x02,0x03,0x04,
0x05,0x06,0x06,0x07,0x08,0x09,0x09,0x10,0x11,0x11,0x12,0x12,0x13,0x13,0x14,0x14,
0x15,0x15,0x16,0x16,0x17,0x17,0x18,0x18,0x19,0x19,0x20,0x20,0x21,0x21,0x22,0x22,
0x23,0x23,0x24,0x24,0x25,0x25,0x25,0x26,0x26,0x27,0x27,0x28,0x28,0x28,0x29,0x29,
0x30,0x30,0x30,0x31,0x31,0x32,0x32,0x32,0x33,0x33,0x33,0x34,0x34,0x35,0x35,0x35,
0x36,0x36,0x37,0x37,0x38,0x38,0x38,0x39,0x39,0x40,0x40,0x40,0x41,0x41,0x42,0x42,
0x43,0x43,0x43,0x44,0x44,0x45,0x45,0x45,0x46,0x46,0x47,0x47,0x48,0x48,0x48,0x49,
0x49,0x50,0x50,0x50,0x51,0x51,0x52,0x52,0x53,0x53,0x54,0x54,0x55,0x55,0x56,0x56,
0x57,0x57,0x58,0x58,0x59,0x59,0x60,0x60,0x61,0x61,0x62,0x62,0x63,0x63,0x64,0x64,
0x65,0x65,0x66,0x66,0x67,0x67,0x68,0x68,0x69,0x69,0x70,0x71,0x71,0x72,0x73,0x73,
0x74,0x74,0x75,0x76,0x76,0x77,0x78,0x78,0x79,0x79,0x80,0x81,0x81,0x82,0x83,0x84,
0x84,0x85,0x86,0x87,0x88,0x89,0x90,0x91,0x92,0x93,0x94,0x95,0x96,0x97,0x98,0x99,
0x99,0x99,0x99,0x99,0x99,0x99,0x99,0x99,0x99,0x99,0x99,0x99,0x99,0x99,0x99,0x99,
0x99,0x99,0x99,0x99,0x99,0x99,0x99,0x99,0x99,0x99
};

/****************************************************************************
*	StartBEEP
*	Function:	This routine configures the necessary hardware to emit a
*				beep from the piezo
****************************************************************************/
void StartBEEP(void)
{
    Flags.SLEEP_STATE = 1;		// Don't let the 924 go to sleep
    Count = BEEP_COUNT;			// Set Count for length of beep
    CCP1CON = 0x0f;				// Set the CCP module to PWM
    PR2 = 122;					// Set the period to 2048Hz
    CCPR1L = 3;					// Set the duty cycle very low
    T2CON = 0b01111101;			// Enable Timer2
    PIR1.TMR2IF = 0;			// Clear the Timer2 Interrupt flag
    PIE1.TMR2IE = 1;			// Enable the Timer2 Interrupt
    return;
}

// Include source files
#include "lcd.c"				// Contains programs that control the LCD
#include "time.c"				// Contains programs for timekeeping

/****************************************************************************
*	Init924
*	Function:	This routine initializes the peripherals and CPU of the 
*				PIC16C924.
****************************************************************************/
void Init924(void)
{
	STATUS.RP0 = 0;			// Change to Bank 0
	STATUS.RP1 = 0;
	OPTION = 0b01010011;	// Pull-ups on,Timer0 internal clk source,
							// Prescaler assigned to Timer0, 1:16
	ADCON0 = 0b11000001;	// Internal RC clk source, Ch0, A/D on
	PORTA = 0;				// Clear ports A,B,C
	PORTB = 0;
	PORTC = 0;
	TRISA = 0b00000111;		// All but RA<0:1> are digital outputs
	TRISB = 0xf0;			// Upper 4 pins are inputs for keys
	TRISC = 0x03;			// RC<0:1> used for Timer1 external crystal
	ADCON1 = 0b00000100;	// RA<0:1,3> are analog
	PIR1.ADIF = 0;			// Clear A/D interrupt flag
	PIE1.ADIE = 1;			// Enable A/D interrupt

	Temp = PORTB;			// Clear mismatch condition on PORTB
	INTCON.RBIF = 0;		// Clear PORTB interrupt flag
	INTCON.RBIE = 1;		// Enable PORTB interrupt

	TMR1H = 0x80;			// Initialize Timer1 to 0x8000
	TMR1L = 0x00;
	T1CON = 0b00001111;		// Timer1 1:1 prescale, Osc enabled, no sync,
							// external clock source, Timer1 on
	PIR1.TMR1IF = 0;		// Clear Timer1 Overflow interrupt flag
	PIE1.TMR1IE = 1;		// Enable Timer1 Overflow interrupt
		
	STATUS.RP1 = 1;			// Go to Bank 2
	LCDPS = 6;				// Set LCD frame freq to 37 Hz, Timer1 clk source
	LCDSE = 0xff;			// Ports D,E,F,G are all LCD pins
	LCDCON = 0b00010111;	// Drive in SLEEP,charge pump on,Timer1 clk src
							// 1/4 mux, 1/3 bias
	LCDD00 = 0;				// Clear all LCD data registers
	LCDD01 = 0;
	LCDD02 = 0;
	LCDD03 = 0;
	LCDD04 = 0;
	LCDD05 = 0;
	LCDD06 = 0;
	LCDD07 = 0;
	LCDD08 = 0;
	LCDD09 = 0;
	LCDD10 = 0;
	LCDD11 = 0;
	LCDD12 = 0;
	LCDD13 = 0;
	LCDD14 = 0;
	LCDD15 = 0;
	LCDCON.LCDEN = 1;		// Enable the LCD Module
	STATUS.RP1 = 0;			// Go to Bank 0
	PIR1.LCDIF = 0;			// Clear LCD interrupt flag
	PIE1.LCDIE = 1;			// Enable LCD interrupt

	Seconds = 0;			// Initialize data variables
	Minutes = 0;
	Hours = 0x12;			// Set time to 12:00AM Sunday
	LStatus = 0;
	DayOfWeek = 0;
	Flags = 0b00010001;
	TempC = 0;
	Ticks = 0;
	Count = BEEP_COUNT;
	Mode = 0b11000111;		// Turn on :,degrees,hours,minutes,day of week

	INTCON.PEIE = 1;		// Enable peripheral interrupts
	INTCON.GIE = 1;			// Enable global interrupts
	return;
}

/****************************************************************************
*	main
*	Function:	Controls the clock.  Calls routines to update the LCD panel,
*				play music, program mode, and display state of sound.
****************************************************************************/
void main(void)
{
	Init924();				// Initialize the PIC16C924

	while(1)
	{
		if(Flags.UPDATE&&Flags.FRAME)	// Refresh the LCD data registers
		{								// based on new data
			Flags.UPDATE = 0;			// Clear the UPDATE flag
			Flags.FRAME = 0;			// Clear the FRAME flag
			UpdateLCD();				// Update LCD data regs
		}
		else if(!Flags.UPDATE&&Flags.FRAME)	// Clear FRAME flag if no UPDATE
			Flags.FRAME = 0;
		
		if(Flags.SET)					// Enter program mode
		{
			Flags.SET = 0;				// Clear the SET, UP flags
			Flags.UP = 0;
			Ticks = 0;					// Clear the Ticks
			Flags.PROGRAM = 1;			// Change to program mode
			while(!Flags.FRAME);		// Wait for next frame to occur
			Flags.FRAME = 0;			// Clear FRAME flag
			Mode = 0b11100111;			// Enable PROG icon on LCD
			UpdateLCD();				// Refresh the LCD
			
			SetTime();					// Call program to set time

			Flags.PROGRAM = 0;			// Exit program mode
			Seconds = 0;				// Clear seconds
			Flags.UPDATE = 1;			// Set UPDATE flag
			Mode = 0b11000111;			// Reset display mode, PROG icon off
		}

		if(LStatus.SOUND)				// Enable/disable hourly beep
		{
			LStatus.SOUND = 0;			// Reset SOUND flag
			DisplaySoundState();		// Display state of hourly beep
		}

		if(!Flags.SLEEP_STATE)			// If 924 can go to sleep, go ahead
			SLEEP();
	}
}

/****************************************************************************
*	__INT
*	Function:	Interrupt service routine for LCD, PORTB, Timer2, Timer1,
*				Timer0, and A/D
****************************************************************************/
void __INT(void)
{
#asm									// "push" W and STATUS
	movwf   temp_WREG
	swapf   STATUS,W
	bcf     STATUS,RP0
	bcf     STATUS,RP1
	movwf   temp_STATUS
	movf	FSR,W
	movwf	temp_FSR
#endasm

	if(PIR1.LCDIF)						// Ok to write to LCD data regs
	{
		Flags.FRAME = 1;				// Set FRAME flag
		PIR1.LCDIF = 0;					// Clear LCD interrupt flag
	}

	if(INTCON.RBIF)						// Key press/release detected
	{
		Delay_Ms_4MHz(5);				// Debounce for 5msec
		Temp = PORTB;					// Read PORTB
		Delay_Ms_4MHz(20);				// Debounce for 20msec more
		if(Temp!=0xf0 && Temp==PORTB)	// If same state as previous read
		{								// and interrupt is not for release
			StartBEEP();     	       // Beep when key is pressed
		
			if(!Temp.SET)				// Set the SET flag
				Flags.SET = 1;
			if(!Temp.UP)				// Set the UP flag
				Flags.UP = 1;
			if(!Temp.SOUND&&!Flags.PROGRAM)
			{							// Toggle the SOUND state
			   if(Flags.SOUND_STATE)
					Flags.SOUND_STATE = 0;
				else
					Flags.SOUND_STATE = 1;
				LStatus.SOUND = 1;		// Set the SOUND flag
			}
		}
		Ticks = 0;						// Reset Ticks, because key was press
		INTCON.RBIF = 0;				// Clear PORTB interrupt flag
	}

	if(PIR1.TMR2IF&&PIE1.TMR2IE)		// Timer2 Overflow used for beep
	{
		if(PIE1.TMR2IE)					// If Timer2 interrupt is enabled
		{
			Count--;					// Decrement count
			if(!Count)					// If count has reached zero
			{
				CCP1CON = 0;			// Disable CCP module
				T2CON = 0;				// Disable Timer2
				CCPR1L = 0;				// Clear the Duty Cycle 
				PIE1.TMR2IE = 0;		// Disable Timer2 Interrupt
				Flags.SLEEP_STATE = 0;	// Enable 924 to SLEEP
			}
		}
		PIR1.TMR2IF = 0;				// Clear Timer2 interrupt flag
	}
	
	if(PIR1.TMR1IF)						// Timer1 Overflow, once every sec
	{
		if(!Flags.PROGRAM)				// If not in program mode
		{
			Seconds++;					// Increment seconds
			if( (Seconds&0x0f) > 0x09)	// check for seconds overflow within
			{							// seconds
				Seconds &= 0xf0;
				Seconds += 0x10;
			}
			if(Seconds >= 0x60)			// check for seconds overflow
				IncMinutes();			// increment minutes routine
			if(Minutes >= 0x60)			// check for hours overflow
				IncHours();				// increment hours routine
			
			TMR1H |= 0x80;				// Set Timer1 to 0x8000 + current time
			Flags.UPDATE = 1;			// Set UPDATE flag

			if(Mode.COLON)				// Toggle whether the colon is on or
				Mode.COLON = 0;			// off every second
			else
				Mode.COLON = 1;
		}
		else							// If in program mode
			Ticks++;					// increment Ticks, used for timeout

		TRISA.THERM_GND = 0;			// Apply power to thermistor
		Delay_10xUs_4MHz(2);			// Allow 20us for sampling
		ADCON0.GO = 1;					// Start a temperture A/D conversion
		NOP();							// Wait for charging cap to
		NOP();							// disconnect from pin
		TRISA.THERM_GND = 1;			// Remove power from thermistor
		PIR1.TMR1IF = 0;				// Clear Timer1 interrupt flag
	}
	
	if(PIR1.ADIF)						// A/D conversion complete
	{
		TempC = ThermTable[ADRES];		// Use converted value for table
		PIR1.ADIF = 0;					// lookup of temperature
	}

#asm									// "pop" W and STATUS
	movf	temp_FSR,W
	movwf	FSR
	swapf   temp_STATUS,W
	movwf   STATUS
	swapf   temp_WREG,F
	swapf   temp_WREG,W
#endasm

	return;
}
