/****************************************************************************
*  Filename: TIME.C
*****************************************************************************
*	Author:	 	Rodger Richey
*	Company:	Microchip Technology Incorporated
*	Revision:	A0
*	Date:		6-14-96
*	Compiled using MPLAB-C Version 00.00.14
*****************************************************************************
*	This file contains the routines to increment time and set the time in
*	program mode.
****************************************************************************/

/****************************************************************************
*	IncMinutes
*	Function:	Increments minutes and performs checks.  Minutes is in BCD.
****************************************************************************/
void IncMinutes(void)
{
	Seconds = 0;					// Clear Seconds
	Minutes++;						// Increment Minutes
	if( (Minutes&0x0f) > 0x09)		// Check for BCD overflow
	{
		Minutes &= 0xf0;
		Minutes += 0x10;
	}
	return;
}

/****************************************************************************
*	IncHours
*	Function:	Increments hours and performs checks.  Hours is in BCD.
****************************************************************************/
void IncHours(void)
{
	if(!Flags.PROGRAM)			// If in program mode, do not clear Minutes
		Minutes = 0;
	Hours++;					// Increment Hours
	if( (Hours&0x0f) > 0x09)	// Check for BCD overflow
	{
		Hours &= 0xf0;
		Hours += 0x10;
	}
	if(Hours == 0x12)			// If hours = 12 then change AM/PM and
	{							// day of the week accordingly
		if(LStatus.AMPM)		// If PM
		{
			LStatus.AMPM = 0;	// change to AM
			if(!Flags.PROGRAM)	// If not in program mode, increment day
			{					// of the week and check for overflow
				DayOfWeek++;
				if(DayOfWeek == 0x07)
					DayOfWeek = 0;
			}
		}
		else					// Otherwise change to PM
			LStatus.AMPM = 1;
	}
	if(Flags.SOUND_STATE)		// Start hourly beep if enabled
		StartBEEP();

	if(Hours == 0x13)			// If hours has overflowed, set to 1
		Hours = 0x01;

	return;
}

/****************************************************************************
*	SetTime
*	Function:	This routine sets the time in program mode.  Allows hours,
*				minutes and day of the week to be configured.
****************************************************************************/
void SetTime(void)
{
	FrameCnt = FRAME_COUNT;		// Initialize the frame counter
	while(!Flags.SET)			// Wait for the SET button to be hit
	{							// before advancing to minutes
		if(Flags.UP)			// If UP button is pressed, inc Minutes
		{
			Flags.UP = 0;
			IncHours();
		}
		if(Flags.FRAME)			// Toggle the display state (blink) every
		{						// FRAME_COUNT frames
			Flags.FRAME = 0;
			FrameCnt--;
			if(!FrameCnt)		// If frame count reaches zero, toggle state
			{
				FrameCnt = FRAME_COUNT;
				BlinkLCD(0x01);
			}
		}
		if(Ticks == 5)			// If user has not pressed a button in 5 secs
			return;				// exit program mode
	}
	Flags.SET = 0;

	FrameCnt = FRAME_COUNT;		// Initialize the frame counter
	while(!Flags.SET)			// Wait for the SET button to be hit
	{							// before advancing to day of the week
		if(Flags.UP)			// If the UP button is hit, inc Minutes
		{
			Flags.UP = 0;
			IncMinutes();
			if(Minutes >= 0x60)	// Check for upper limit 
				Minutes = 0;
		}
		if(Flags.FRAME)			// Toggle the display state (blink) every
		{						// FRAME_COUNT frames
			Flags.FRAME = 0;
			FrameCnt--;
			if(!FrameCnt)		// If frame count reaches zero, toggle state
			{
				FrameCnt = FRAME_COUNT;
				BlinkLCD(0x02);
			}
		}
		if(Ticks == 5)			// If user has not pressed a button in 5 secs
			return;				// exit program mode
	}
	Flags.SET = 0;

	FrameCnt = FRAME_COUNT;		// Initialize the frame counter
	while(!Flags.SET)			// Wait for the SET button to be hit
	{							// before exiting program mode
		if(Flags.UP)			// If the UP key is pressed, inc day of week
		{
			Flags.UP = 0;
			DayOfWeek++;
			if(DayOfWeek == 0x07)	// Check for overflow
				DayOfWeek = 0;
		}
		if(Flags.FRAME)			// Toggle the display state (blink) every
		{						// FRAME_COUNT frames
			Flags.FRAME = 0;
			FrameCnt--;
			if(!FrameCnt)
			{
				FrameCnt = FRAME_COUNT;
				BlinkLCD(0x04);
			}
		}
		if(Ticks == 5)			// If user has not pressed a button in 5 secs
			return;				// exit program mode
	}
	Flags.SET = 0;
	return;
}
