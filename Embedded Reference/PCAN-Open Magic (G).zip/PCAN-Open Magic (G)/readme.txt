PCANOpen Magic

Please use the code in the file "activation-code.txt" to register the software.

