;PROGRAM DEFINITIONS
;
#define Fosc 				.4000000
#define T1_PreScale 		.2
#define	T1CON_MASK			b'00010001'			;PS=1:2, osc enabled, internal clock,tmr1 ON
#define	T1_100MS			.50000				;50K * 2PS (i.e. 2us/pulse) = 100ms


;#define Milisec 			.1000
;#define Timer1tick_ms 		-((Fosc)/(4*T1_PreScale*Milisec))	; 1ms
#define C_SECOND			.10					;10 * 100ms

#define LEARN_PERIOD		.60					;in seconds - 1 minute learning period
#define REFRESH_PERIOD		.31					;MINUTES before autonomous shutdown


NBITS				EQU		.48					;packet length
MIN					EQU		.560

PR2_HEAT_PERIOD		EQU		.31					;PWM period for heaters
PR2_BUZZ_PERIOD		EQU		.249
MAX_READING			EQU		.255				;????
SECOND_MSG_PERIOD	EQU		.2					;miliseconds, gap between repetitions 
BUZZ_PERIOD			EQU		.3					;miliseconds


#DEFINE	F_LEARN				BUFFER5,1	;learn mode indication
#DEFINE	F_BEEP				BUFFER5,2	;

#DEFINE	F_START				FLAGS1,0
#DEFINE	F_LEFT_SIDE			FLAGS1,1
#DEFINE	F_TWO_COMMANDS		FLAGS1,2
#DEFINE	F_MATCH				FLAGS1,3
#DEFINE	F_PWM_LEFT			FLAGS1,4
#DEFINE	F_PWM_RIGHT			FLAGS1,5
#DEFINE	F_PWM_BUZZ			FLAGS1,6
#DEFINE	F_EXPECT_2ND_MSG	FLAGS1,7

#DEFINE	F_PKT_ACT_PENDING	FLAGS2,0
#DEFINE	F_EMERGENCY			FLAGS2,1
#DEFINE	F_UPDATE_PWM		FLAGS2,2
#DEFINE	F_EMERG_LIMITS		FLAGS2,3
#DEFINE	F_EMERG_AFT1		FLAGS2,4
#DEFINE	F_EMERG_AFT2		FLAGS2,5



#DEFINE	NTC_READ	PORTA,0						;AN0
#DEFINE	AN1			PORTA,1						;
#DEFINE				PORTA2		"NOT USED"		;
#DEFINE	VREF		PORTA,3						;VREF for A/D conversion
#DEFINE				PORTA4		"NOT USED"		;
#DEFINE				PORTA5		"NOT USED"		;
#DEFINE	MASKA		b'11001011'					;
#DEFINE	INITA		b'00000000'					;


#DEFINE	RF_RX		PORTB,0						;used as "RF" by receive.inc
#DEFINE	AFT1_ERROR	PORTB,1						;
#DEFINE	AFT2_ERROR	PORTB,2						;
#DEFINE				PORTB3	"NOT USED"			;
#DEFINE				PORTB4	"NOT USED"			;
#DEFINE				PORTB5	"NOT USED"			;
#DEFINE				PORTB6	"NOT USED"			;
#DEFINE				PORTB7	"NOT USED"			;
#DEFINE	MASKB		b'00000111'					;
#DEFINE	INITB		b'00000000'					;

#DEFINE	ENA_PW2		PORTC,0						;
#DEFINE	PW2_BUZZ	PORTC,1						;
#DEFINE	PWM1		PORTC,2						;
#DEFINE	ENA_BUZZ	PORTC,3						;
#DEFINE	ALARM_AFT1	PORTC,4						;
#DEFINE	ALARM_AFT2	PORTC,5						;
#DEFINE	EEsda		PORTC,6						;EEDATA	; EEPROM DATA LINE FOR 24xxxx
#DEFINE	EEscl		PORTC,7						;EECLOCK; EEPROM SERIAL CLOCK FOR 24xxxx	
#DEFINE	MASKC		b'01000000'					;
#DEFINE	INITC		b'00000000'					;

#DEFINE	TRISC_ENAPWM2	TRISC,0					;
#DEFINE	TRISC_ENABUZZ	TRISC,3					;
