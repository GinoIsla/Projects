
#define _p18f4580
#ifdef _p18f4580
#include <p18f4580.h>
#else
#include <p18f2680.h>
#endif
