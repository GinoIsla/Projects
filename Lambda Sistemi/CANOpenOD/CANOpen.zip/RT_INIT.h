#define dummy	0
